package com.example.quanlyktx;

import android.app.Activity;
import android.os.Bundle;
import android.widget.Button;
import android.widget.TextView;

public class StatisticsActivity extends Activity {

    TextView tvTotalStudents, tvTotalRooms, tvAvailableRooms, tvFullRooms;
    Button btnRefreshStatistics;

    DatabaseHelper databaseHelper;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_statistics);

        databaseHelper = new DatabaseHelper(this);

        tvTotalStudents = findViewById(R.id.tvTotalStudents);
        tvTotalRooms = findViewById(R.id.tvTotalRooms);
        tvAvailableRooms = findViewById(R.id.tvAvailableRooms);
        tvFullRooms = findViewById(R.id.tvFullRooms);

        btnRefreshStatistics = findViewById(R.id.btnRefreshStatistics);

        loadStatistics();

        btnRefreshStatistics.setOnClickListener(v -> loadStatistics());
    }

    private void loadStatistics() {
        int totalStudents = databaseHelper.getTotalStudents();
        int totalRooms = databaseHelper.getTotalRooms();
        int availableRooms = databaseHelper.getAvailableRooms();
        int fullRooms = databaseHelper.getFullRooms();

        tvTotalStudents.setText("Tổng số sinh viên: " + totalStudents);
        tvTotalRooms.setText("Tổng số phòng: " + totalRooms);
        tvAvailableRooms.setText("Phòng còn trống: " + availableRooms);
        tvFullRooms.setText("Phòng đã đầy: " + fullRooms);
    }
}
package com.example.quanlyktx;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import java.util.ArrayList;

public class RoomActivity extends Activity {

    EditText edtRoomCode, edtRoomName, edtRoomCapacity;
    Button btnAddRoom, btnRefreshRoom;
    ListView listRooms;

    DatabaseHelper databaseHelper;
    ArrayList<String> roomList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_room);

        databaseHelper = new DatabaseHelper(this);

        edtRoomCode = findViewById(R.id.edtRoomCode);
        edtRoomName = findViewById(R.id.edtRoomName);
        edtRoomCapacity = findViewById(R.id.edtRoomCapacity);

        btnAddRoom = findViewById(R.id.btnAddRoom);
        btnRefreshRoom = findViewById(R.id.btnRefreshRoom);

        listRooms = findViewById(R.id.listRooms);

        loadRooms();

        btnAddRoom.setOnClickListener(v -> addRoom());
        btnRefreshRoom.setOnClickListener(v -> loadRooms());
    }

    private void addRoom() {
        String roomCode = edtRoomCode.getText().toString().trim();
        String roomName = edtRoomName.getText().toString().trim();
        String capacityText = edtRoomCapacity.getText().toString().trim();

        if (roomCode.isEmpty() || roomName.isEmpty() || capacityText.isEmpty()) {
            Toast.makeText(this, "Vui lòng nhập đầy đủ thông tin phòng", Toast.LENGTH_SHORT).show();
            return;
        }

        int capacity;

        try {
            capacity = Integer.parseInt(capacityText);
        } catch (Exception e) {
            Toast.makeText(this, "Sức chứa phải là số", Toast.LENGTH_SHORT).show();
            return;
        }

        if (capacity <= 0) {
            Toast.makeText(this, "Sức chứa phải lớn hơn 0", Toast.LENGTH_SHORT).show();
            return;
        }

        boolean result = databaseHelper.addRoom(roomCode, roomName, capacity);

        if (result) {
            Toast.makeText(this, "Thêm phòng thành công", Toast.LENGTH_SHORT).show();
            clearInput();
            loadRooms();
        } else {
            Toast.makeText(this, "Không thể thêm. Mã phòng có thể đã tồn tại", Toast.LENGTH_LONG).show();
        }
    }

    private void loadRooms() {
        roomList = databaseHelper.getAllRooms();

        ArrayAdapter<String> adapter = new ArrayAdapter<>(
                this,
                android.R.layout.simple_list_item_1,
                roomList
        );

        listRooms.setAdapter(adapter);
    }

    private void clearInput() {
        edtRoomCode.setText("");
        edtRoomName.setText("");
        edtRoomCapacity.setText("");

        edtRoomCode.requestFocus();
    }
}
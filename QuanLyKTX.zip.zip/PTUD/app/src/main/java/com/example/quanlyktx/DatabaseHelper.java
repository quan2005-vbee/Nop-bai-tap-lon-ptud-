package com.example.quanlyktx;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import java.util.ArrayList;

public class DatabaseHelper extends SQLiteOpenHelper {

    private static final String DATABASE_NAME = "QuanLyKTX.db";
    private static final int DATABASE_VERSION = 1;

    private static final String TABLE_STUDENTS = "students";
    private static final String TABLE_ROOMS = "rooms";

    public DatabaseHelper(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        String createRoomTable = "CREATE TABLE " + TABLE_ROOMS + " (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "room_code TEXT UNIQUE, " +
                "room_name TEXT, " +
                "capacity INTEGER, " +
                "current_count INTEGER DEFAULT 0)";

        String createStudentTable = "CREATE TABLE " + TABLE_STUDENTS + " (" +
                "id INTEGER PRIMARY KEY AUTOINCREMENT, " +
                "student_code TEXT UNIQUE, " +
                "name TEXT, " +
                "class_name TEXT, " +
                "phone TEXT, " +
                "room_code TEXT)";

        db.execSQL(createRoomTable);
        db.execSQL(createStudentTable);
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_STUDENTS);
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_ROOMS);
        onCreate(db);
    }

    public boolean addRoom(String roomCode, String roomName, int capacity) {
        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put("room_code", roomCode);
        values.put("room_name", roomName);
        values.put("capacity", capacity);
        values.put("current_count", 0);

        long result = db.insert(TABLE_ROOMS, null, values);

        return result != -1;
    }

    public boolean addStudent(String studentCode, String name, String className, String phone, String roomCode) {
        if (!isRoomExists(roomCode)) {
            return false;
        }

        if (!isRoomAvailable(roomCode)) {
            return false;
        }

        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put("student_code", studentCode);
        values.put("name", name);
        values.put("class_name", className);
        values.put("phone", phone);
        values.put("room_code", roomCode);

        long result = db.insert(TABLE_STUDENTS, null, values);

        if (result != -1) {
            increaseRoomCount(roomCode);
            return true;
        }

        return false;
    }

    public boolean updateStudent(int id, String studentCode, String name, String className, String phone, String newRoomCode) {
        String oldRoomCode = getRoomCodeOfStudent(id);

        if (oldRoomCode == null) {
            return false;
        }

        boolean isChangingRoom = !oldRoomCode.equals(newRoomCode);

        if (isChangingRoom) {
            if (!isRoomExists(newRoomCode)) {
                return false;
            }

            if (!isRoomAvailable(newRoomCode)) {
                return false;
            }
        }

        SQLiteDatabase db = this.getWritableDatabase();

        ContentValues values = new ContentValues();
        values.put("student_code", studentCode);
        values.put("name", name);
        values.put("class_name", className);
        values.put("phone", phone);
        values.put("room_code", newRoomCode);

        int result = db.update(TABLE_STUDENTS, values, "id=?", new String[]{String.valueOf(id)});

        if (result > 0) {
            if (isChangingRoom) {
                decreaseRoomCount(oldRoomCode);
                increaseRoomCount(newRoomCode);
            }
            return true;
        }

        return false;
    }

    public boolean deleteStudent(int id) {
        String roomCode = getRoomCodeOfStudent(id);

        SQLiteDatabase db = this.getWritableDatabase();

        int result = db.delete(TABLE_STUDENTS, "id=?", new String[]{String.valueOf(id)});

        if (result > 0) {
            if (roomCode != null) {
                decreaseRoomCount(roomCode);
            }
            return true;
        }

        return false;
    }

    public ArrayList<String> getAllStudents() {
        ArrayList<String> list = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_STUDENTS + " ORDER BY id DESC", null);

        if (cursor.moveToFirst()) {
            do {
                list.add(formatStudent(cursor));
            } while (cursor.moveToNext());
        }

        cursor.close();
        return list;
    }

    public ArrayList<String> searchStudents(String keyword) {
        ArrayList<String> list = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();

        String search = "%" + keyword + "%";

        Cursor cursor = db.rawQuery(
                "SELECT * FROM " + TABLE_STUDENTS +
                        " WHERE student_code LIKE ? OR name LIKE ? OR class_name LIKE ? OR phone LIKE ? OR room_code LIKE ?" +
                        " ORDER BY id DESC",
                new String[]{search, search, search, search, search}
        );

        if (cursor.moveToFirst()) {
            do {
                list.add(formatStudent(cursor));
            } while (cursor.moveToNext());
        }

        cursor.close();
        return list;
    }

    private String formatStudent(Cursor cursor) {
        int id = cursor.getInt(cursor.getColumnIndexOrThrow("id"));
        String studentCode = cursor.getString(cursor.getColumnIndexOrThrow("student_code"));
        String name = cursor.getString(cursor.getColumnIndexOrThrow("name"));
        String className = cursor.getString(cursor.getColumnIndexOrThrow("class_name"));
        String phone = cursor.getString(cursor.getColumnIndexOrThrow("phone"));
        String roomCode = cursor.getString(cursor.getColumnIndexOrThrow("room_code"));

        return "ID: " + id +
                " | MSV: " + studentCode +
                "\nTên: " + name +
                " | Lớp: " + className +
                "\nSĐT: " + phone +
                " | Phòng: " + roomCode;
    }

    public String[] getStudentById(int id) {
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.rawQuery(
                "SELECT * FROM " + TABLE_STUDENTS + " WHERE id=?",
                new String[]{String.valueOf(id)}
        );

        if (cursor.moveToFirst()) {
            String[] data = new String[5];

            data[0] = cursor.getString(cursor.getColumnIndexOrThrow("student_code"));
            data[1] = cursor.getString(cursor.getColumnIndexOrThrow("name"));
            data[2] = cursor.getString(cursor.getColumnIndexOrThrow("class_name"));
            data[3] = cursor.getString(cursor.getColumnIndexOrThrow("phone"));
            data[4] = cursor.getString(cursor.getColumnIndexOrThrow("room_code"));

            cursor.close();
            return data;
        }

        cursor.close();
        return null;
    }

    public ArrayList<String> getAllRooms() {
        ArrayList<String> list = new ArrayList<>();
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.rawQuery("SELECT * FROM " + TABLE_ROOMS + " ORDER BY id DESC", null);

        if (cursor.moveToFirst()) {
            do {
                int id = cursor.getInt(cursor.getColumnIndexOrThrow("id"));
                String roomCode = cursor.getString(cursor.getColumnIndexOrThrow("room_code"));
                String roomName = cursor.getString(cursor.getColumnIndexOrThrow("room_name"));
                int capacity = cursor.getInt(cursor.getColumnIndexOrThrow("capacity"));
                int currentCount = cursor.getInt(cursor.getColumnIndexOrThrow("current_count"));

                list.add("ID: " + id +
                        " | Mã phòng: " + roomCode +
                        "\nTên phòng: " + roomName +
                        "\nSố lượng: " + currentCount + "/" + capacity);
            } while (cursor.moveToNext());
        }

        cursor.close();
        return list;
    }

    public boolean isRoomExists(String roomCode) {
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.rawQuery(
                "SELECT id FROM " + TABLE_ROOMS + " WHERE room_code=?",
                new String[]{roomCode}
        );

        boolean exists = cursor.getCount() > 0;

        cursor.close();
        return exists;
    }

    public boolean isRoomAvailable(String roomCode) {
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.rawQuery(
                "SELECT capacity, current_count FROM " + TABLE_ROOMS + " WHERE room_code=?",
                new String[]{roomCode}
        );

        if (cursor.moveToFirst()) {
            int capacity = cursor.getInt(cursor.getColumnIndexOrThrow("capacity"));
            int currentCount = cursor.getInt(cursor.getColumnIndexOrThrow("current_count"));

            cursor.close();

            return currentCount < capacity;
        }

        cursor.close();
        return false;
    }

    private String getRoomCodeOfStudent(int studentId) {
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.rawQuery(
                "SELECT room_code FROM " + TABLE_STUDENTS + " WHERE id=?",
                new String[]{String.valueOf(studentId)}
        );

        if (cursor.moveToFirst()) {
            String roomCode = cursor.getString(cursor.getColumnIndexOrThrow("room_code"));
            cursor.close();

            return roomCode;
        }

        cursor.close();
        return null;
    }

    private void increaseRoomCount(String roomCode) {
        SQLiteDatabase db = this.getWritableDatabase();

        db.execSQL(
                "UPDATE " + TABLE_ROOMS + " SET current_count = current_count + 1 WHERE room_code=?",
                new Object[]{roomCode}
        );
    }

    private void decreaseRoomCount(String roomCode) {
        SQLiteDatabase db = this.getWritableDatabase();

        db.execSQL(
                "UPDATE " + TABLE_ROOMS + " SET current_count = CASE WHEN current_count > 0 THEN current_count - 1 ELSE 0 END WHERE room_code=?",
                new Object[]{roomCode}
        );
    }

    public int getTotalStudents() {
        return getNumberByQuery("SELECT COUNT(*) FROM " + TABLE_STUDENTS);
    }

    public int getTotalRooms() {
        return getNumberByQuery("SELECT COUNT(*) FROM " + TABLE_ROOMS);
    }

    public int getAvailableRooms() {
        return getNumberByQuery("SELECT COUNT(*) FROM " + TABLE_ROOMS + " WHERE current_count < capacity");
    }

    public int getFullRooms() {
        return getNumberByQuery("SELECT COUNT(*) FROM " + TABLE_ROOMS + " WHERE current_count >= capacity");
    }

    private int getNumberByQuery(String sql) {
        SQLiteDatabase db = this.getReadableDatabase();

        Cursor cursor = db.rawQuery(sql, null);

        int number = 0;

        if (cursor.moveToFirst()) {
            number = cursor.getInt(0);
        }

        cursor.close();
        return number;
    }
}
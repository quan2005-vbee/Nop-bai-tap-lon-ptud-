package com.example.quanlyktx;

import android.app.Activity;
import android.os.Bundle;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;
import java.util.ArrayList;

public class StudentActivity extends Activity {

    EditText edtStudentCode, edtStudentName, edtStudentClass, edtStudentPhone, edtStudentRoom;
    Button btnAddStudent, btnUpdateStudent, btnDeleteStudent, btnSearchStudent, btnRefreshStudent, btnClearStudent;
    ListView listStudents;

    DatabaseHelper databaseHelper;
    ArrayList<String> studentList;

    int selectedStudentId = -1;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_student);

        databaseHelper = new DatabaseHelper(this);

        edtStudentCode = findViewById(R.id.edtStudentCode);
        edtStudentName = findViewById(R.id.edtStudentName);
        edtStudentClass = findViewById(R.id.edtStudentClass);
        edtStudentPhone = findViewById(R.id.edtStudentPhone);
        edtStudentRoom = findViewById(R.id.edtStudentRoom);

        btnAddStudent = findViewById(R.id.btnAddStudent);
        btnUpdateStudent = findViewById(R.id.btnUpdateStudent);
        btnDeleteStudent = findViewById(R.id.btnDeleteStudent);
        btnSearchStudent = findViewById(R.id.btnSearchStudent);
        btnRefreshStudent = findViewById(R.id.btnRefreshStudent);
        btnClearStudent = findViewById(R.id.btnClearStudent);

        listStudents = findViewById(R.id.listStudents);

        loadStudents();

        btnAddStudent.setOnClickListener(v -> addStudent());
        btnUpdateStudent.setOnClickListener(v -> updateStudent());
        btnDeleteStudent.setOnClickListener(v -> deleteStudent());
        btnSearchStudent.setOnClickListener(v -> searchStudent());
        btnRefreshStudent.setOnClickListener(v -> loadStudents());
        btnClearStudent.setOnClickListener(v -> clearInput());

        listStudents.setOnItemClickListener((parent, view, position, id) -> {
            String item = studentList.get(position);

            selectedStudentId = getIdFromItem(item);

            String[] data = databaseHelper.getStudentById(selectedStudentId);

            if (data != null) {
                edtStudentCode.setText(data[0]);
                edtStudentName.setText(data[1]);
                edtStudentClass.setText(data[2]);
                edtStudentPhone.setText(data[3]);
                edtStudentRoom.setText(data[4]);

                Toast.makeText(this, "Đã chọn sinh viên ID: " + selectedStudentId, Toast.LENGTH_SHORT).show();
            }
        });
    }

    private void addStudent() {
        String code = edtStudentCode.getText().toString().trim();
        String name = edtStudentName.getText().toString().trim();
        String className = edtStudentClass.getText().toString().trim();
        String phone = edtStudentPhone.getText().toString().trim();
        String room = edtStudentRoom.getText().toString().trim();

        if (code.isEmpty() || name.isEmpty() || className.isEmpty() || phone.isEmpty() || room.isEmpty()) {
            Toast.makeText(this, "Vui lòng nhập đầy đủ thông tin", Toast.LENGTH_SHORT).show();
            return;
        }

        boolean result = databaseHelper.addStudent(code, name, className, phone, room);

        if (result) {
            Toast.makeText(this, "Thêm sinh viên thành công", Toast.LENGTH_SHORT).show();
            clearInput();
            loadStudents();
        } else {
            Toast.makeText(this, "Không thể thêm. Kiểm tra mã sinh viên, mã phòng hoặc phòng đã đầy", Toast.LENGTH_LONG).show();
        }
    }

    private void updateStudent() {
        if (selectedStudentId == -1) {
            Toast.makeText(this, "Vui lòng chọn sinh viên cần sửa", Toast.LENGTH_SHORT).show();
            return;
        }

        String code = edtStudentCode.getText().toString().trim();
        String name = edtStudentName.getText().toString().trim();
        String className = edtStudentClass.getText().toString().trim();
        String phone = edtStudentPhone.getText().toString().trim();
        String room = edtStudentRoom.getText().toString().trim();

        if (code.isEmpty() || name.isEmpty() || className.isEmpty() || phone.isEmpty() || room.isEmpty()) {
            Toast.makeText(this, "Vui lòng nhập đầy đủ thông tin", Toast.LENGTH_SHORT).show();
            return;
        }

        boolean result = databaseHelper.updateStudent(selectedStudentId, code, name, className, phone, room);

        if (result) {
            Toast.makeText(this, "Sửa sinh viên thành công", Toast.LENGTH_SHORT).show();
            clearInput();
            loadStudents();
        } else {
            Toast.makeText(this, "Không thể sửa. Kiểm tra mã phòng hoặc phòng đã đầy", Toast.LENGTH_LONG).show();
        }
    }

    private void deleteStudent() {
        if (selectedStudentId == -1) {
            Toast.makeText(this, "Vui lòng chọn sinh viên cần xóa", Toast.LENGTH_SHORT).show();
            return;
        }

        boolean result = databaseHelper.deleteStudent(selectedStudentId);

        if (result) {
            Toast.makeText(this, "Xóa sinh viên thành công", Toast.LENGTH_SHORT).show();
            clearInput();
            loadStudents();
        } else {
            Toast.makeText(this, "Xóa thất bại", Toast.LENGTH_SHORT).show();
        }
    }

    private void searchStudent() {
        String keyword = edtStudentCode.getText().toString().trim();

        if (keyword.isEmpty()) {
            keyword = edtStudentName.getText().toString().trim();
        }

        if (keyword.isEmpty()) {
            keyword = edtStudentRoom.getText().toString().trim();
        }

        if (keyword.isEmpty()) {
            Toast.makeText(this, "Nhập mã sinh viên, tên hoặc mã phòng để tìm", Toast.LENGTH_SHORT).show();
            return;
        }

        studentList = databaseHelper.searchStudents(keyword);

        showList(studentList);

        if (studentList.size() == 0) {
            Toast.makeText(this, "Không tìm thấy sinh viên", Toast.LENGTH_SHORT).show();
        }
    }

    private void loadStudents() {
        selectedStudentId = -1;

        studentList = databaseHelper.getAllStudents();

        showList(studentList);
    }

    private void showList(ArrayList<String> list) {
        ArrayAdapter<String> adapter = new ArrayAdapter<>(
                this,
                android.R.layout.simple_list_item_1,
                list
        );

        listStudents.setAdapter(adapter);
    }

    private void clearInput() {
        selectedStudentId = -1;

        edtStudentCode.setText("");
        edtStudentName.setText("");
        edtStudentClass.setText("");
        edtStudentPhone.setText("");
        edtStudentRoom.setText("");

        edtStudentCode.requestFocus();
    }

    private int getIdFromItem(String item) {
        try {
            int start = item.indexOf("ID:") + 3;
            int end = item.indexOf("|");

            String idText = item.substring(start, end).trim();

            return Integer.parseInt(idText);
        } catch (Exception e) {
            return -1;
        }
    }
}
plugins {
    id("com.android.application")
}

android {
    namespace = "com.example.quanlyktx"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.example.quanlyktx"
        minSdk = 23
        targetSdk = 34
        versionCode = 1
        versionName = "1.0"
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_1_8
        targetCompatibility = JavaVersion.VERSION_1_8
    }
}

dependencies {

}